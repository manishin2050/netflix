from django.urls import path
from netflix import views

urlpatterns = [
    path('',views.Home,name='Home'),
    path('register/',views.Register,name='Register'),
    path('login/', views.Login, name='Login'),
    path('logout/', views.Logout, name='Logout'),

]
