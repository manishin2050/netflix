from django.shortcuts import render,HttpResponse,redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
import requests

# Create your views here.

def Home(request):
    return render(request,"index.html")

def Register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        if password1 != password2:
            messages.error(request, '⚠️ Passwords Do Not Match! Try Again')
            return redirect('Register')

        if User.objects.filter(username=username).exists():
            messages.error(request, '⚠️ Username Already Exists!')
            return redirect('Register')

        if User.objects.filter(email=email).exists():
            messages.error(request, '⚠️ Email Address Already Exists!')
            return redirect('Register')

        user = User.objects.create_user(username=username, email=email)
        user.set_password(password1)
        user.save()

        messages.success(request, '✅ Regristration Successful!')
        return redirect('Register')
    return render(request,"Register.html")

def Login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)

        if not User.objects.filter(username=username).exists():
            messages.error(request, '⚠️ Username Does Not Exist!')
            return redirect('Login')

        if user is None:
            messages.error(request, '⚠️ Username or Password Is Incorrect!!')
            return redirect('Login')

        if user is not None:
            login(request, user)
            return redirect('/')

    return render(request, 'Login.html')

def Logout(request):
    logout(request)
    # messages.success(request, '✅ Successfully Logged Out!')
    return redirect('/')


# def fetch_data_from_api(request):
#     # API endpoint URL
#     api_url = 'https://api.example.com/data'

#     try:
#         # Make a GET request to the API
#         response = requests.get(api_url)

#         # Check if the request was successful (status code 200)
#         if response.status_code == 200:
#             # Convert the JSON response to a Python dictionary
#             data = response.json()
#             # Pass the data to the template for rendering
#             return render(request, 'template_name.html', {'data': data})
#         else:
#             # Handle other status codes if needed
#             return render(request, 'error_template.html', {'error': 'Failed to fetch data from API'})
#     except Exception as e:
#         # Handle exceptions
#         return render(request, 'error_template.html', {'error': str(e)})
